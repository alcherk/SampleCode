/*
    Copyright (C) 2014 Apple Inc. All Rights Reserved.
    See LICENSE.txt for this sample’s licensing information
    
    Abstract:
    
                This is the master view controller that pushes other CloudKitAtlas view controllers onto the view view controller hiearchy.
            
*/

@import UIKit;

@interface AAPLMasterViewController : UITableViewController

@end

