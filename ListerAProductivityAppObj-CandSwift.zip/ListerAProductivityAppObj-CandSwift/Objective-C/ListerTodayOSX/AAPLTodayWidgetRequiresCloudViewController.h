/*
    Copyright (C) 2014 Apple Inc. All Rights Reserved.
    See LICENSE.txt for this sample’s licensing information
    
    Abstract:
    
                The AAPLTodayWidgetRequiresCloudViewController class is an NSViewController subclass that displays the "The Lister Today widget requires iCloud." row in the app extension.
            
*/

@import Cocoa;

@interface AAPLTodayWidgetRequiresCloudViewController : NSViewController
@end
