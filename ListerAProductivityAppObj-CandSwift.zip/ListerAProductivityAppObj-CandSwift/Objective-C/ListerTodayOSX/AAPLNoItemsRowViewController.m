/*
     Copyright (C) 2014 Apple Inc. All Rights Reserved.
     See LICENSE.txt for this sample’s licensing information
     
     Abstract:
     
                 The AAPLNoItemsRowViewController class is an NSViewController subclass that displays the "No Items" row in the app extension.
              
 */

#import "AAPLNoItemsRowViewController.h"

@implementation AAPLNoItemsRowViewController

@end
