# SceneKit Vehicle Demo

This sample code shows how to simulate a vehicle using the SCNPhysicsVehicle behaviour. The vehicle can be controller with either the accelerometer or a game controller. It also illustrate basic physics interaction and game overlays done with SpriteKit.

## Requirements

### Build

iOS 8

### Runtime

iOS 8

Copyright (C) 2014 Apple Inc. All rights reserved.
