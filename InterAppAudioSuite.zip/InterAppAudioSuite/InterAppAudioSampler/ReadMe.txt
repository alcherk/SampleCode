### InterAppAudioSample ###

This app is an example of a node application that is a sampler. This demo shows a sampler that publishes itself as a remote instrument that plays audio upon receiving midi events from a host application.

It also includes a keyboard for triggering notes locally.

===========================================================================
Copyright (C) 2013-2014 Apple Inc. All rights reserved.
