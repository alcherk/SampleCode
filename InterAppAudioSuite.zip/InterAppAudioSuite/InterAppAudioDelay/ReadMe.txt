### InterAppAudioDelay ###

Inter-app-audio allows applications to publish themselves so that they can be used in conjunction with other audio applications.
This example illustrates how to publish and control a delay effect, which can be used by another application.

Demo Application Notes
	• Parameters for and names delay are based on actual parameters of AUDelay Audio Unit with linear slider response. In the interest of simplicity,
	  making custom logarithmic sliders is not shown.
	• Transport controls are shown in this demo to illustrate how to create and control a remote transport. In the context of this demo suite, that functionality
	  is not practically useful.

===========================================================================
Copyright (C) 2013-2014 Apple Inc. All rights reserved.
