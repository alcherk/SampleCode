# Creating a Game with Scene Kit

This sample shows how to build a basic game using Scene Kit, demonstrating physics, rendering techniques, lighting, actions and animation.

## Requirements

### Build

iOS 8 or OS X 10.10 SDK

### Runtime

iOS 8 or OS X 10.10 

Copyright (C) 2014 Apple Inc. All rights reserved.
