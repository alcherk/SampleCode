//
//  main.m
//  Bananas iOS
//

#import <UIKit/UIKit.h>

#import "AAPLAppDelegateIOS.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AAPLAppDelegateIOS class]));
    }
}
