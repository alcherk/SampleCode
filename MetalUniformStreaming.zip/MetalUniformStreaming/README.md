# MetalUniformStreaming

Metal creates data buffer resources that can be read and written to on the CPU and GPU asynchronously. This example demonstrates using a data buffer to set uniforms for the vertex and fragment shaders.

## Requirements

### Build

iOS 8 SDK

### Runtime

iOS 8, 64 bit devices

Copyright (C) 2014 Apple Inc. All rights reserved.
