/*
  Copyright (C) 2014 Apple Inc. All Rights Reserved.
  See LICENSE.txt for this sample’s licensing information
  
  Abstract:
  
        Defines the main entry point for OS X Adventure
      
*/

import Cocoa

NSApplicationMain(C_ARGC, C_ARGV)
