/*
 <codex>
 <abstract>View controller in charge of forward geocoding.
 </abstract>
 </codex>
 */

#import <UIKit/UIKit.h>

@interface ForwardViewController : UITableViewController

@end
