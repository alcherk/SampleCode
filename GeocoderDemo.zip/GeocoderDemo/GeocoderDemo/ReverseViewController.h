/*
 <codex>
 <abstract>View controller in charge of reverse geocoding.
 </abstract>
 </codex>
 */

#import <UIKit/UIKit.h>

@interface ReverseViewController : UITableViewController

@end
