/*
 <codex>
 <abstract>The sample's application delegate.
 </abstract>
 </codex>
 */

#import <UIKit/UIKit.h>

@interface GeocoderDemoAppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end
