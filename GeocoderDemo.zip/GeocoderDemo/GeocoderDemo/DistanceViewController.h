/*
 <codex>
 <abstract>View controller in charge of measuring distance between 2 locations.
 </abstract>
 </codex>
 */

#import <UIKit/UIKit.h>

@interface DistanceViewController : UITableViewController

@end
