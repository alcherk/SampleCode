/*
 <codex>
 <abstract>Main source file to this sample application.
 </abstract>
 </codex>
 */

#import <UIKit/UIKit.h>

#import "GeocoderDemoAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([GeocoderDemoAppDelegate class]));
        return retVal;
    }
}
