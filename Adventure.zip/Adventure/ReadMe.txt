Adventure
=========

Adventure demonstrates how to build a complete game using Sprite Kit.

This sample is described in detail in the accompanying code:Explained document.

*Important* The iOS target requires the iOS 7 SDK, the OS X target requires the OS X 10.9 SDK.
